/**
 * \file
 *
 * \brief Starter Kit Demo.
 *
 * Copyright (c) 2014-2015 Atmel Corporation. All rights reserved.
 *
 * \asf_license_start
 *
 * \page License
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an
 *    Atmel microcontroller product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * \asf_license_stop
 *
 */

/**
 * \mainpage Starter Kit Demo
 *
 * \section Purpose
 *
 * The Starter Kit Demo will help new users get familiar with Atmel's
 * SAM family of microcontrollers. This demo features the IO1 and OLED1
 * extension boards for the SAM4 Xplained Pro.
 *
 * \section Requirements
 *
 * This package can be used with SAM Xplained Pro evaluation kits.
 *
 * \section Description
 *
 * The demonstration program can operate in 3 different modes; temperature
 * information, light sensor information and SD card status.
 * The user can switch between the various mode by pressing Button1.
 * When running in mode 3 (SD card content), the user can browse the SD
 * content using Button2 (previous) and Button3 (next). Filenames are directly
 * printed on the OLED screen.
 *
 * IO1 extension must be connected on EXT2.
 * OLED1 extension must be connected on EXT3.
 *
 */
/*
 * Support and FAQ: visit <a href="http://www.atmel.com/design-support/">Atmel Support</a>
 */

#include <asf.h>
#include <string.h>

extern void led(int);

extern unsigned int test (unsigned int);

static void configure_adc(void)
{
	/* Configure ADC pin for light sensor. */
	//gpio_configure_pin(LIGHT_SENSOR_GPIO, LIGHT_SENSOR_FLAGS);

	/* Enable ADC clock. */
	pmc_enable_periph_clk(ID_ADC);

	/* Configure ADC. */
	adc_init(ADC, sysclk_get_cpu_hz(), 1000000, ADC_MR_STARTUP_SUT0);
	adc_enable_channel(ADC, ADC_CHANNEL_1);
	adc_configure_trigger(ADC, ADC_TRIG_SW, 1);
}

int main(void)
{	
	int adc_value;
	int normalized_adc_value;
	int value[6];
	int test_value;
	
	sysclk_init();
	board_init();
	ssd1306_init();
	
	//Configure ADC
	configure_adc();
	
	char test_file_name[] = "0:test.txt";
	Ctrl_status status;
	FRESULT res;
	FATFS fs;
	FIL file_object;
	const usart_serial_options_t usart_serial_options = {
		.baudrate =	  115200,
		.charlength = 0,
		.paritytype = UART_MR_PAR_NO,
		.stopbits =   false,
	};
	
	char blank = " ";
	
	irq_initialize_vectors();
	cpu_irq_enable();
	
	sysclk_init();
	board_init();
	stdio_serial_init(CONSOLE_UART, &usart_serial_options);
	
	sd_mmc_init();
	
	memset(&fs, 0, sizeof(FATFS));
	res = f_mount(LUN_ID_SD_MMC_0_MEM, &fs);
	test_file_name[0] = LUN_ID_SD_MMC_0_MEM + '0';
	res = f_open(&file_object,
		(char const *)test_file_name,
		FA_CREATE_ALWAYS | FA_WRITE);
	f_close(&file_object);
	
	printf("This works");

	//start ADC
	adc_start(ADC);
	
	int total;
	int max_vol = 0;
	int count = 0;
	int choice = 0;
	
	while(true){
		
		// get audio information.
		adc_value = adc_get_channel_value(ADC, ADC_CHANNEL_1);

		//normalize
		normalized_adc_value = abs(adc_value - 1716) / 2;
		int status = adc_get_channel_status(ADC, ADC_CHANNEL_1);
		
		total = adc_value;
		total -= 1716;
		
		sprintf(value, "%d", total);
		//get string with value

		printf(value, "%d", total);
		printf(" ");
		
		count++;
		
		if(total > max_vol) max_vol = total;
		
		if(count > 100)
		{		
			//adjust led
			if(max_vol < 30) choice = 1;
			else if( max_vol > 100) choice = 3;
			else choice = 2;
			
			led(choice);
			
			max_vol = 0;
			count = 0;
		}
		
		/*
		//clear screen
		ssd1306_clear();
		ssd1306_clear();
		
		//print value
		ssd1306_set_page_address(0);
		ssd1306_set_column_address(0);
		ssd1306_write_text(value);
		
		//print light bar
		ssd1306_set_page_address(3);
		ssd1306_set_column_address(0);
		for(uint32_t i=0; i<normalized_adc_value; i++)
		ssd1306_write_text("/");
		
		//ssd1306_clear();
		*/
		//delay_ms(5);
	}
	

	
}

